<?php
//session_start();
$conn= new mysqli('localhost','root','','postbank_hr')or die("Could not connect to mysql".mysqli_error($conn));
?>
