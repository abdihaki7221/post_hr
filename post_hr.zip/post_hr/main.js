

    var select_box_element = document.querySelector('#select_box');

    dselect(select_box_element, {
        search: true
    });



    var select_box_element = document.querySelector('#select_two');

    dselect(select_box_element, {
        search: true
    });
